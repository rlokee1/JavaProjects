package File_Handling;

public class FileDelete {

}
