package TaskMaster;

public class Swag {
    int a=1;
    public static void main(String[]args){
        Swag s1 = new Swag();
        Swag s2 = new Swag();
        Swag s3 = new Swag();
        Swag s4 = new Swag();
        Swag s5 = new Swag();
        Swag s6 = new Swag();
        System.out.println(s1.a);
        System.out.println(s2.a= s1.a+1);
        System.out.print(s3.a=s2.a+1);
        System.out.print(s4.a=s3.a+1);
        System.out.print(s5.a=s4.a+1);
        System.out.print(s6.a=s5.a+1);



    }
}
