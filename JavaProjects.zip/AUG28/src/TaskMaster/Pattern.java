package TaskMaster;

public class Pattern {
    public static void main(String[]args){
        int n=3;
        for (int i=n;i>=1;i--){
            for(int j=1;j<=n-i;j++){
                System.out.print("   ");
        }
            for (int k=1;k<=i;k++){
                System.out.print(" "+i+" ");
            }
            System.out.println(" ");
    }
}
}

