package TaskMaster;

import java.util.ArrayList;
import java.util.List;

public class New {
    public static void main(String[] args) {
        ArrayList<Object> li = new ArrayList<>();
        li.add(101);
        li.add("sri");
        li.add(10);
        li.add(79);
        li.add('H');
        li.add("101");
        li.add("sri");
        li.add(101);
        li.add(79);
        System.out.println(li);

    }

}
