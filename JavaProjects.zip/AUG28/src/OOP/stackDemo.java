package OOP;

public class stackDemo {
    public static void main(String[] args) {


        Stack s1 = new Stack();

        s1.push(3);
        s1.push(4);
        s1.push(6);
        s1.push(7);


        System.out.println(s1.pop());
    }
}
