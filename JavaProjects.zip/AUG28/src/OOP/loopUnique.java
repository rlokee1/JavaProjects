package OOP;

public class loopUnique {
    public static void main(String[]args){

        for(int i=3;i<=10;i+=(i==3?2:5))
        {
        System.out.println(i);
        }
    }
}
