package OOP;

public class ForLoop {
    public static void main(String[] args){
        int i,j;
        for(i=1;i<=5;i++)
        {
            System.out.println("");
            for(j=1;j<=5;j++) {
                if(j==4)
                    break;
            System.out.print("1");
            }
        }
    }
}
