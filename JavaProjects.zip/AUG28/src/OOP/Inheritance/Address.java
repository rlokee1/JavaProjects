package OOP.Inheritance;

class Address {
        String city;
        String state;
        int zipcode;

    Address(String city,String state,int zipcode) {
       this.city=city;
       this.state=state;
       this.zipcode=zipcode;
    }
}

