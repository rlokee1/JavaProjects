//package OOP;
//
//import java.util.concurrent.Callable;
//
//public class Constructors360 {
//
//// Default Constructor
//        Constructors360() { System.out.println("Default constructor"); }
//
//        // Driver function
//        public static void main(String[] args)
//        {
//            Callable<Con> callable = new Callable<Object>()
//           ; hello = new GFG();
//        }
//    }
//
