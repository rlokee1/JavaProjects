package OOP;

public class typeCast {
        public static void main(String[]args){
            byte a=10;
            int b = a;

            int c=a+2;
            byte d = (byte) c;

            System.out.println(b);
            System.out.println(d);
            System.out.println(a);
        }
}
