//package Array360;
//
//import java.util.Scanner;
//
//public class sortArray {
//    public static void main(String[]args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the numbers you want to store : ");
//        int arr=sc.nextInt();
//
//        int temp,i,j;
//
//        for (i=0;i<arr.length;i++){
//            for (j=i+1;j<arr.length;j++){
//                if(arr[i]>arr[j]){
//                    temp=arr[i];
//                    arr[i]=arr[j];
//                    arr[j]=temp;
//                }
//            }System.out.print(arr[i]+" ");
//        }
//    }
//}
