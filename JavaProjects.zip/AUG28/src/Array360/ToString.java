package Array360;

import java.util.Arrays;

public class ToString {
    public static void main(String[] args) {
        int[] a1 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        String[] b = {"zero", "one", "two", "three"};
        char[] c = {'A', 'r', 'r', 'a', 'y'};
        int sum = 0;
        for (char k : c) {
            sum += k;
            System.out.println(k);
        }
        System.out.println(sum);

        int[] a = {1,1,2,2,4};
        int l = removeDuplicates(a);
        System.out.println("After removing duplicates ");
        for (int i = 0; i < l; i++) {
            System.out.println(a[i] + " ");
        }
    }

    static int removeDuplicates(int[] a) {
        int i = 0;
        for (int j = 1; j < a.length; j++) {
            if (a[i] != a[j]) {
                i++;
                a[i] = a[j];
            }
        }
        return i + 1;
    }
}
