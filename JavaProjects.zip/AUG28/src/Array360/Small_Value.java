package Array360;

import java.util.Arrays;
import java.util.Scanner;

public class Small_Value {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the required size of the array : ");
            int arrsize = sc.nextInt();
            int[] arr1 = new int[arrsize];
            System.out.println("Enter the elements of the array :");
            int j;
            int small = arr1[0];
            int secondsmall = -1;

            for (j = 0; j < arrsize; j++) {
                if (arr1[j] < small) {
                    small = arr1[j];
                }
            }

            for (j = 0; j < arrsize; j++) {
                if (arr1[j] < small) {
                    secondsmall = small;
                    small = arr1[j];
                } else if (arr1[j] != small && arr1[j] < secondsmall) {
                    secondsmall = arr1[j];
                }
            }

            System.out.println("The Entered array is " + Arrays.toString(arr1));
            System.out.println("The Minimum value in the array is " + small);
            System.out.println("The Second Minimum value in the array is " + secondsmall);
            System.out.println('\n' + "Enter the number zero to exit (or) to continue press any number:");
            int exit = sc.nextInt();
            if (exit == 0) {
                break;
            }
        }
    }
}