package Array360;

import java.util.Arrays;
import java.util.Scanner;

public class userinputArray {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Enter the required size of the array : ");
            int arrsize = sc.nextInt();
            int[] arr = new int[arrsize];
            System.out.println("Enter the elements of the array :");
            int i;
            int large = arr[0];
            int secondlarge= -1;

            for (i = 0; i < arrsize; i++) {
                arr[i] = sc.nextInt();
                if(arr[i]>large) {
                    large = arr[i];
                }
            }
            for (i = 0; i < arrsize; i++) {
                if(arr[i]>secondlarge && arr[i]<large){
                    secondlarge = arr[i];
                }
            }
            /*for (i = 0; i < arrsize; i++) {
                if(arr[i]>large){
                    secondlarge = large;
                    large = arr[i];
                }
                else if(arr[i]< large && arr[i] > secondlarge){
                    secondlarge = arr[i];
                }
            }*/

            System.out.println("The Entered array is " + Arrays.toString(arr));
            System.out.println("The Maximum value in the array is " + large);
            System.out.println("The Second Maximum value in the array is " + secondlarge);
            System.out.println('\n'+"Enter the number zero to exit (or) to continue press any number:");
            int exit = sc.nextInt();
            if (exit == 0) {
                break;
            }
        }
    }
}