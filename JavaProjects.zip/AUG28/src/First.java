public class First {
    public static void main(String[] args)
    {
        System.out.println("My name is Lokesh");

        int a= 5;
        System.out.println(a+=6);
        int b=10;
        int c= a++ + ++a - ++a + b++;

        System.out.println(a++);
        System.out.println(b++);
        System.out.println(c);
        int d=1%2;
        System.out.println("d is" + d);
    }
}
